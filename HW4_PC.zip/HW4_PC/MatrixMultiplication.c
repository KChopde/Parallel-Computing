#include <stdio.h>
#include <stdlib.h>
#include <omp.h>

#define MATRIX_SIZE 2048

int main() {

double start; 
double end;
start = omp_get_wtime(); 
int i,j,k;

    // Allocate memory for the input and result matrices
  int **matrixA = (int **)malloc(MATRIX_SIZE * sizeof(int *));
  int **matrixB = (int **)malloc(MATRIX_SIZE * sizeof(int *));
  int **result = (int **)malloc(MATRIX_SIZE * sizeof(int *));

  for (int i = 0; i < MATRIX_SIZE; i++) {
    matrixA[i] = (int *)malloc(MATRIX_SIZE * sizeof(int));
    matrixB[i] = (int *)malloc(MATRIX_SIZE * sizeof(int));
    result[i] = (int *)malloc(MATRIX_SIZE * sizeof(int));
  }

 // Generate the input matrices
  for (int i = 0; i < MATRIX_SIZE; i++) {
    for (int j = 0; j < MATRIX_SIZE; j++) {
      matrixA[i][j] = 1;
      matrixB[i][j] = 2;
    }
  }


//parallel block
#pragma omp parallel for schedule(runtime) private(i,j,k) shared(matrixA,matrixB,result)
    for (i = 0; i < MATRIX_SIZE; ++i) {
        for (j = 0; j < MATRIX_SIZE; ++j) {
          result[i][j]=0;
            for (k = 0; k < MATRIX_SIZE; ++k) {
                result[i][j] += matrixA[i][k] * matrixB[k][j];
            }
        }
    }


// Open the output file
  FILE *fp = fopen("result.txt", "w");
  if (fp == NULL) {
    perror("fopen");
    exit(1);
  }



  // Print the final result to the result file
  for (int i = 0; i < MATRIX_SIZE; i++) {
    for (int j = 0; j < MATRIX_SIZE; j++) {
      fprintf(fp, "%d ", result[i][j]);
    }
    fprintf(fp, "\n");
  }

  // Close the result file
  fclose(fp);
end = omp_get_wtime(); 
printf("Work took %f seconds\n", end - start);

exit(0);

}