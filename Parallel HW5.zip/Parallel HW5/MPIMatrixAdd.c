#include <stdio.h>
#include <stdlib.h>
#include "mpi.h"

#define MATRIX_SIZE 2048
#define BLOCK_SIZE 256
#define MASTER_RANK 0

void generateInitialMatrix(int **matrix, int rows, int cols) {
    
    for (int i = 0; i < rows; i++) {
        int startValue = 1;
        for (int j = 0; j < cols; j++) {
            matrix[i][j] = startValue++;
        }
    }
}

void printMatrixToFile(FILE *file, int **matrix, int rows, int cols) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            fprintf(file, "%d ", matrix[i][j]);
        }
        fprintf(file, "\n");
    }
}

int main(int argc, char *argv[]) {
    int rank, size;
    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    int **matrixA, **matrixB, **localMatrixA, **localMatrixB, **localResult, **finalResult;
    int i, j, k;

    // Allocate memory for matrices
    matrixA = (int **)malloc(MATRIX_SIZE * sizeof(int *));
    matrixB = (int **)malloc(MATRIX_SIZE * sizeof(int *));

    localMatrixA = (int **)malloc(MATRIX_SIZE * sizeof(int *));
    localMatrixB = (int **)malloc(MATRIX_SIZE * sizeof(int *));
    localResult = (int **)malloc(MATRIX_SIZE * sizeof(int *));
    finalResult = (int **)malloc(MATRIX_SIZE * sizeof(int *));

    if (matrixA == NULL || matrixB == NULL || localMatrixA == NULL || localMatrixB == NULL || localResult == NULL || finalResult == NULL) {
        fprintf(stderr, "Memory allocation failed.\n");
        MPI_Abort(MPI_COMM_WORLD, 1);
    }

    for (i = 0; i < MATRIX_SIZE; i++) {
        matrixA[i] = (int *)malloc(MATRIX_SIZE * sizeof(int));
        matrixB[i] = (int *)malloc(MATRIX_SIZE * sizeof(int));
        finalResult[i] = (int *)malloc(MATRIX_SIZE * sizeof(int));
        localResult[i] = (int *)malloc(MATRIX_SIZE * sizeof(int));
        localMatrixA[i] = (int *)malloc(MATRIX_SIZE * sizeof(int));
        localMatrixB[i] = (int *)malloc(MATRIX_SIZE * sizeof(int));
    }



    // Generate initial matrices in the master process
    if (rank == MASTER_RANK) {
        generateInitialMatrix(matrixA, MATRIX_SIZE, MATRIX_SIZE);
        generateInitialMatrix(matrixB, MATRIX_SIZE, MATRIX_SIZE);

        for(int i=0;i<8;i++)
        {
            MPI_Send(&matrixA[BLOCK_SIZE*i][0], BLOCK_SIZE * MATRIX_SIZE, MPI_INT, i+1, 0, MPI_COMM_WORLD);
            MPI_Send(&matrixB[BLOCK_SIZE*i][0], BLOCK_SIZE * MATRIX_SIZE, MPI_INT, i+1, 1, MPI_COMM_WORLD);
        }

        for(int i=0;i<8;i++)
        {
            MPI_Recv(&finalResult[BLOCK_SIZE*i][0], BLOCK_SIZE * MATRIX_SIZE, MPI_INT, i+1, 2, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        }

// // Print or save the final result
        
        // Store the final result in a file
        FILE *file;
        file = fopen("result.txt", "w");

        if (file == NULL) {
            fprintf(stderr, "Error opening file.\n");
            MPI_Abort(MPI_COMM_WORLD, 1);
        }

        printMatrixToFile(file, finalResult, MATRIX_SIZE, MATRIX_SIZE);

        fclose(file);

    }




    // Send local results to Process 0
    if (rank != MASTER_RANK) {
        MPI_Recv(&localMatrixA[(rank - 1 ) * BLOCK_SIZE][0], BLOCK_SIZE * MATRIX_SIZE, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        MPI_Recv(&localMatrixB[(rank - 1 ) * BLOCK_SIZE][0], BLOCK_SIZE * MATRIX_SIZE, MPI_INT, 0, 1, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
    
        // Compute local addition
        for (i = (rank - 1) * BLOCK_SIZE; i < (rank - 1) * BLOCK_SIZE + 255; i++) {
            for (j = 0; j < MATRIX_SIZE; j++) {
                localResult[i][j] = localMatrixA[i][j] + localMatrixB[i][j];
            }
        }
        printf("Process rank %d: Done\n", rank);

        MPI_Send(&localResult[(rank-1)*BLOCK_SIZE][0], BLOCK_SIZE * MATRIX_SIZE, MPI_INT, 0, 2, MPI_COMM_WORLD);
        // MPI_Send(&my_rank,1,MPI_INT,dest,tag,MPI_COMM_WORLD);
    
    
    } 
    





    // Clean up
    for (i = 0; i < MATRIX_SIZE; i++) {
        free(matrixA[i]);
        free(matrixB[i]);
        free(finalResult[i]);
    }

    for (i = 0; i < BLOCK_SIZE; i++) {
        free(localMatrixA[i]);
        free(localMatrixB[i]);
        free(localResult[i]);
    }

    free(matrixA);
    free(matrixB);
    free(localMatrixA);
    free(localMatrixB);
    free(localResult);
    free(finalResult);

    MPI_Finalize();

    return 0;
}
