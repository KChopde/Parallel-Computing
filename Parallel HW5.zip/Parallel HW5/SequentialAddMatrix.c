#include <stdio.h>
#include <time.h>

#define SIZE 2048

// Function to add two matrices and store the result in the third matrix
void addMatrices(int matrix1[SIZE][SIZE], int matrix2[SIZE][SIZE], int result[SIZE][SIZE]) {
    for (int i = 0; i < SIZE; i++) {
        for (int j = 0; j < SIZE; j++) {
            result[i][j] = matrix1[i][j] + matrix2[i][j];
        }
    }
}

int main() {
    //clock_t starttime=clock();
    time_t begin = time(NULL);
    int matrix1[SIZE][SIZE], matrix2[SIZE][SIZE], result[SIZE][SIZE];

   for (int i = 0; i < SIZE; i++) {
        int startValue = 1;
        for (int j = 0; j < SIZE; j++) {
            matrix1[i][j] = startValue++;
            matrix2[i][j] = startValue++;
        }
    }
  

    // Add matrices
  addMatrices(matrix1, matrix2, result);

  time_t end = time(NULL);
    // calculate elapsed time by finding difference (end - begin)
  printf("The elapsed time is %d seconds", (end - begin));
  
 // Open the output file
  FILE *fp = fopen("result.txt", "w");
  if (fp == NULL) {
    perror("fopen");
  }

  // Print the final result to the result file
  for (int i = 0; i < SIZE; i++) {
    for (int j = 0; j < SIZE; j++) {
      fprintf(fp, "%d ", result[i][j]);
    }
    fprintf(fp, "\n");
  }

  // Close the result file
  fclose(fp);

    return 0;
}
